<?php if(!defined('PG_VERSION')){exit;}?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>welcome to phpGrace</title>
</head>
<body>
	<div style="font-size:22px; line-height:1.8em; font-family:微软雅黑; padding:100px;">
		<span style="font-size:60px; font-family:微软雅黑;">(: </span><br />
		Welcome to phpGrace ! <a href="http://www.phpgrace.com" target="_blank">访问官网</a>
	</div>
</body>
</html>