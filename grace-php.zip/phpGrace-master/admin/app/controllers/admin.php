<?php
/**
 * 后台管理系统基础文件 后端控制器都会继承此控制
 * 可以实现一些全局的基础功能，如 : 登录检查、权限、等后台开发常用的功能
 * @link      http://www.phpGrace.com
 * @copyright Copyright (c) 2010-2020 phpGrace.com
 * @license   http://www.phpGrace.com/license
 * @package   phpGrace
 * @author    haijun liu mail:5213606@qq.com
 * @version   1.2.0
 */
class adminController extends grace{
	
	public function index(){
		
	}
	
}