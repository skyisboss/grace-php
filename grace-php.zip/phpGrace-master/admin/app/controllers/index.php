<?php
/**
 * 后台管理系统入口文件
 * 建议后台的大部分功能控制器都继承 admin 基础控制器
 * 来实现一些全局的基础功能，如 : 登录检查、权限、等后台开发常用的功能
 * @link      http://www.phpGrace.com
 * @copyright Copyright (c) 2010-2020 phpGrace.com
 * @license   http://www.phpGrace.com/license
 * @package   phpGrace
 * @author    haijun liu mail:5213606@qq.com
 * @version   1.2.0
 */
class indexController extends adminController{
	
	public function index(){
		
	}
	
}